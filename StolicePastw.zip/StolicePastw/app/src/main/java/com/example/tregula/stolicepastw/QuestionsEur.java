package com.example.tregula.stolicepastw;

public class QuestionsEur {

    public String myQuestionsEur[] = {
            "Albania",
            "Andora",
            "Austria",
            "Belgia",
            "Białoruś",
            "Bośnia i Hercegowina",
            "Bułgaria",
            "Chorwacja",
            "Czechy",
            "Dania",
            "Estonia",
            "Finlandia",
            "Francja",
            "Grecja",
            "Hiszpania",
            "Holandia",
            "Irlandia",
            "Islandia",
            "Jugosławia",
            "Lichtenstein",
            "Litwa",
            "Luksemburg",
            "Łotwa",
            "Macedonia",
            "Malta",
            "Mołdawia",
            "Monako",
            "Niemcy",
            "Norwegia",
            "Polska",
            "Portugalia",
            "Rosja",
            "Rumunia",
            "San Marino",
            "Słowacja",
            "Słowenia",
            "Szwajcaria",
            "Szwecja",
            "Ukraina",
            "Watykan",
            "Węgry",
            "Wielka Brytania",
            "Włochy",

    };

    private String myChoicesEur[][] =
            {
                    {"Zagrzeb", "Valletta", "Tirana", "Amsterdam"},
                    {"Wilno", "Rzym", "Berlin", "Andora"},
                    {"Wiedeń", "Bruksela", "Mińsk", "Ateny"},
                    {"Vaduz", "Watykan", "Belgrad", "Bruksela"},
                    {"Mińsk", "Tirana", "Warszawa", "Berlin"},
                    {"Tallin", "Valletta", "Oslo", "Sarajewo"},
                    {"Rejkiawik", "Sofia", "Vaduz", "Bratysława"},
                    {"Zagrzeb", "Tirana", "Dublin", "Bruksela"},
                    {"Rejkiawik", "Praga", "Sztokholm", "Budapeszt"},
                    {"Praga", "Sztokholm", "Madryt", "Kopenhaga"},
                    {"Paryż", "Sofia", "Tallin", "Dublin"},
                    {"Mińsk", "Skopje", "Rzym", "Helsinki"},
                    {"Kijów", "Sarajewo", "Kijów", "Paryż"},
                    {"Ateny", "Tirana", "Rzym", "Kiszyniów"},
                    {"Kopenhaga", "Ryga", "Helsinki", "Madryt"},
                    {"Lizbona", "Rejkiawik", "Oslo", "Amsterdam"},
                    {"Londyn", "Praga", "Bruksela", "Dublin"},
                    {"Belgrad", "Paryż", "Rejkiawik", "Lublana"},
                    {"Oslo", "Ateny", "Luksemburg", "Belgrad"},
                    {"Madryt", "Moskwa", "Andora", "Vaduz"},
                    {"Mińsk", "Monako", "Amsterdam", "Wilno"},
                    {"Monako", "Mińsk", "Berlin", "Luksemburg"},
                    {"Moskwa", "Madryt", "Berno", "Ryga"},
                    {"Oslo", "Skopje", "Luksemburg", "Bratysława"},
                    {"Budapeszt", "Valletta", "Paryż", "Lublana"},
                    {"Kiszyniów", "Praga", "Bukareszt", "Londyn"},
                    {"Lizbona", "Kijów", "Rejkiawik", "Monako"},
                    {"Kiszyniów", "Kopenhaga", "Berlin", "Ryga"},
                    {"Lizbona", "Kiszyniów", "Oslo", "Rzym"},
                    {"Londyn", "Kijów", "Warszawa", "Sarajewo"},
                    {"Lublana", "Helsinki", "Lizbona", "Skopje"},
                    {"Luksemburg", "Dublin", "Moskwa", "Sofia"},
                    {"Monako", "Bukareszt", "Rajkiawik", "Sztokholm"},
                    {"Moskwa", "Budapeszt", "San Marino", "Tallin"},
                    {"Oslo", "Bruksela", "Bratysława", "Tirana"},
                    {"Ryga", "Bratysława", "Lublana", "Vaduz"},
                    {"Rzym", "Berno", "Berno", "Valletta"},
                    {"Skopje", "Berlin", "Sztokholm", "Warszawa"},
                    {"Sztokholm", "Belgrad", "Kijów", "Watykan"},
                    {"Valletta", "Ateny", "Watykan", "Wiedeń"},
                    {"Warszawa", "Andora", "Budapeszt", "Wilno"},
                    {"Watykan", "Amsterdam", "Londyn", "Zagrzeb"},
                    {"Berno", "Rzym", "Watykan", "Tirana"}
            };

    private String myCorrectAnswersEur[] =
            {
                    "Tirana",
                    "Andora",
                    "Wiedeń",
                    "Bruksela",
                    "Mińsk",
                    "Sarajewo",
                    "Sofia",
                    "Zagrzeb",
                    "Praga",
                    "Kopenhaga",
                    "Tallin",
                    "Helsinki",
                    "Paryż",
                    "Ateny",
                    "Madryt",
                    "Amsterdam",
                    "Dublin",
                    "Rejkiawik",
                    "Belgrad",
                    "Vaduz",
                    "Wilno",
                    "Luksemburg",
                    "Ryga",
                    "Skopje",
                    "Valletta",
                    "Kiszyniów",
                    "Monako",
                    "Berlin",
                    "Oslo",
                    "Warszawa",
                    "Lizbona",
                    "Moskwa",
                    "Bukareszt",
                    "San Marino",
                    "Bratysława",
                    "Lublana",
                    "Berno",
                    "Sztokholm",
                    "Kijów",
                    "Watykan",
                    "Budapeszt",
                    "Londyn",
                    "Rzym"
            };


    public String getQuestionEur(int a) {
        String question = myQuestionsEur[a];
        return question;
    };

    public String getChoice1Eur(int a) {
        String choice = myChoicesEur[a][0];
        return choice;
    };

    public String getChoice2Eur(int a) {
        String choice = myChoicesEur[a][1];
        return choice;
    };

    public String getChoice3Eur(int a) {
        String choice = myChoicesEur[a][2];
        return choice;
    };

    public String getChoice4Eur(int a) {
        String choice = myChoicesEur[a][3];
        return choice;
    };

    public String getCorrectAnswerEur(int a) {
        String answer = myCorrectAnswersEur[a];
        return answer;
    };
}
