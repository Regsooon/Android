package com.example.tregula.stolicepastw;

public class QuestionsApln {
    public String myQuestionsApln[] =
            {
                    "Bahamy",
                    "Belize",
                    "Dominikana",
                    "Gwatemala",
                    "Haiti",
                    "Honduras",
                    "Jamajka",
                    "Kanada",
                    "Kostaryka",
                    "Kuba",
                    "Meksyk",
                    "Nikaragua",
                    "Panama",
                    "Salwador",
                    "USA"
            };

    public String myChoicesApln[][]=
            {
                    {"Waszyngton","Nassau ","Tegucigalpa","Belmopan"},
                    {"Tegucigalpa","Belmopan","Santo Domigo","Gwatemala"},
                    {"Santo Domigo","Belmopan","Port au Prince","Hawana"},
                    {"San Salwador","Gwatemala","Nassau ","Kingstone"},
                    {"San Jose","Port au Prince","Kingstone","Managua"},
                    {"Port au Prince","Tegucigalpa","Gwatemala","Meksyk"},
                    {"Panama","Kingstone","Belmopan","Nassau "},
                    {"Ottawa","Gwatemala","Hawana","Port au Prince"},
                    {"Nassau ","San Jose","Managua","Panama"},
                    {"Meksyk","Hawana","Managua","Port au Prince"},
                    {"Managua","Meksyk","Ottawa","San Jose"},
                    {"Kingstone","Managua","Panama","San Salwador"},
                    {"Hawana","Panama","San Jose","Santo Domigo"},
                    {"Gwatemala","Waszyngton","San Salwador","Tegucigalpa"},
                    {"Belmopan","Tegucigalpa","Waszyngton","Hawana"}
            };
    public String myCorrectAnswersApln[]=
            {
                    "Nassau ",
                    "Belmopan",
                    "Santo Domigo",
                    "Gwatemala",
                    "Port au Prince",
                    "Tegucigalpa",
                    "Kingstone",
                    "Ottawa",
                    "San Jose",
                    "Hawana",
                    "Meksyk",
                    "Managua",
                    "Panama",
                    "San Salwador",
                    "Waszyngton"
            };
    public String getQuestionApln(int a) {
        String question = myQuestionsApln[a];
        return question;
    };

    public String getChoice1Apln(int a) {
        String choice = myChoicesApln[a][0];
        return choice;
    };

    public String getChoice2Apln(int a) {
        String choice = myChoicesApln[a][1];
        return choice;
    };

    public String getChoice3Apln(int a) {
        String choice = myChoicesApln[a][2];
        return choice;
    };

    public String getChoice4Apln(int a) {
        String choice = myChoicesApln[a][3];
        return choice;
    };

    public String getCorrectAnswerApln(int a) {
        String answer = myCorrectAnswersApln[a];
        return answer;
    };
}
