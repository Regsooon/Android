package com.example.tregula.stolicepastw;

public class QuestionsAzj {
    public String myQuestionsAzj[] =
            {
                    "Afganistan",
                    "Arabia Saudyjska",
                    "Armenia",
                    "Azerbejdżan",
                    "Bahrajn",
                    "Bangladesz",
                    "Bhutan",
                    "Brunei Bandar",
                    "Chiny",
                    "Cypr",
                    "Filipiny",
                    "Gruzja",
                    "Indie",
                    "Indonezja",
                    "Irak",
                    "Iran",
                    "Izrael",
                    "Japonia",
                    "Jemen",
                    "Jordania",
                    "Kambodża",
                    "Katar",
                    "Kazachstan",
                    "Kirgistan",
                    "Korea Płd.",
                    "Korea Płn.",
                    "Kuwejt",
                    "Laos",
                    "Liban",
                    "Maledywy",
                    "Malezja",
                    "Mongolia",
                    "Myanmar (Birma)",
                    "Nepal",
                    "Oman",
                    "Pakistan",
                    "Sri Lanka (Cejlon)",
                    "Syria",
                    "Tadżykistan",
                    "Tajlandia",
                    "Tajwan",
                    "Turcja",
                    "Turkmenistan",
                    "Timor Wschodni",
                    "Uzbekistan",
                    "Wietnam",
                    "Zjedn. Emiraty Arabskie"
            };

    public String myChoicesAzj[][] =
            {
                    {"Abu Zabi","Kabul","Tokio","Wientian"},
                    {"Al.-Manama","Ar-Rijad","Thimpu","Ułan"},
                    {"Amman","Erewan","Tel-Awiw","Tokio"},
                    {"Ankara","Baku","Teheran","Thimpu"},
                    {"Ar-Rijad","Al.-Manama","Tbilisi","Tel-Awiw"},
                    {"Astana","Dakka","Seri Begawano","Teheran"},
                    {"Aszchabad","Thimpu","Sana","Tbilisi"},
                    {"Bagdad","Seri Begawano","Phnom","Taszkent"},
                    {"Baku","Pekin","Pekin","Tajpej"},
                    {"Bangkok","Nikozja","Nikozja","Seul"},
                    {"Bejrut","Manila","Nikozja","Seri Begawano"},
                    {"Biszkek","Tbilisi","Kabul","Sana"},
                    {"Dakka","Delhi","Erewan","Rangun"},
                    {"Damaszek","Dżakarta","Rangun","Phnom"},
                    {"Dauha","Bagdad","Delhi","Phenian"},
                    {"Delhi","Teheran","Dauha","Pekin"},
                    {"Dili","Tel-Awiw","Dakka","Nikozja"},
                    {"Duszanbe","Tokio","Baku","Maskat"},
                    {"Dżakarta","Sana","Bagdad","Manila"},
                    {"Erewan","Amman","Astana","Male"},
                    {"Hanoi","Phnom","Ar-Rijad","Kuwejt"},
                    {"Islamabad","Dauha","Amman","Kuala Lumpur"},
                    {"Kabul","Astana","Al.-Manama","Kolombo"},
                    {"Katmandu","Biszkek","Abu Zabi","Katmandu"},
                    {"Kolombo","Seul","Ankara","Kabul"},
                    {"Kuala Lumpur","Phenian","Aszchabad","Islamabad"},
                    {"Kuwejt","Kuwejt","Bangkok","Hanoi"},
                    {"Male","Wientian","Bejrut","Erewan"},
                    {"Manila","Bejrut","Biszkek","Dżakarta"},
                    {"Maskat","Male","Damaszek","Duszanbe"},
                    {"Nikozja","Kuala Lumpur","Dili","Dili"},
                    {"Pekin","Ułan","Duszanbe","Delhi"},
                    {"Phenian","Rangun","Hanoi","Dauha"},
                    {"Phnom","Katmandu","Islamabad","Damaszek"},
                    {"Rangun","Maskat","Katmandu","Dakka"},
                    {"Sana","Islamabad","Kolombo","Biszkek"},
                    {"Seri Begawano","Kolombo","Kuala Lumpur","Bejrut"},
                    {"Seul","Damaszek","Kuwejt","Bangkok"},
                    {"Tajpej","Duszanbe","Male","Baku"},
                    {"Taszkent","Bangkok","Maskat","Bagdad"},
                    {"Tbilisi","Tajpej","Phenian","Aszchabad"},
                    {"Teheran","Ankara","Rangun","Astana"},
                    {"Tel-Awiw","Aszchabad","Seul","Ar-Rijad"},
                    {"Thimpu","Dili","Tajpej","Ankara"},
                    {"Tokio","Taszkent","Taszkent","Amman"},
                    {"Ułan","Hanoi","Ułan","Al.-Manama"},
                    {"Wientian","Abu Zabi","Wientian","Abu Zabi"},
            };
    public String myCorrectAnswersAzj[] =
            {
                    "Kabul",
                    "Ar-Rijad",
                    "Erewan",
                    "Baku",
                    "Al.-Manama",
                    "Dakka",
                    "Thimpu",
                    "Seri Begawano",
                    "Pekin",
                    "Nikozja",
                    "Manila",
                    "Tbilisi",
                    "Delhi",
                    "Dżakarta",
                    "Bagdad",
                    "Teheran",
                    "Tel-Awiw",
                    "Tokio",
                    "Sana",
                    "Amman",
                    "Phnom",
                    "Dauha",
                    "Astana",
                    "Biszkek",
                    "Seul",
                    "Phenian",
                    "Kuwejt",
                    "Wientian",
                    "Bejrut",
                    "Male",
                    "Kuala Lumpur",
                    "Ułan",
                    "Rangun",
                    "Katmandu",
                    "Maskat",
                    "Islamabad",
                    "Kolombo",
                    "Damaszek",
                    "Duszanbe",
                    "Bangkok",
                    "Tajpej",
                    "Ankara",
                    "Aszchabad",
                    "Dili",
                    "Taszkent",
                    "Hanoi",
                    "Abu Zabi",
            };

    public String getQuestionAzj(int a) {
        String question = myQuestionsAzj[a];
        return question;
    };

    public String getChoice1Azj(int a) {
        String choice = myChoicesAzj[a][0];
        return choice;
    };

    public String getChoice2Azj(int a) {
        String choice = myChoicesAzj[a][1];
        return choice;
    };

    public String getChoice3Azj(int a) {
        String choice = myChoicesAzj[a][2];
        return choice;
    };

    public String getChoice4Azj(int a) {
        String choice = myChoicesAzj[a][3];
        return choice;
    };

    public String getCorrectAnswerAzj(int a) {
        String answer = myCorrectAnswersAzj[a];
        return answer;
    };
}
