package com.example.tregula.stolicepastw;

public class QuestionsApld
{
    public String myQuestionsApld[]=
            {
                    "Argentyna",
                    "Boliwia",
                    "Brazylia",
                    "Chile",
                    "Ekwador",
                    "Gujana",
                    "Kolumbia",
                    "Paragwaj",
                    "Peru",
                    "Surinam",
                    "Urugwaj",
                    "Wenezuela",
            };

    public String myChoicesApld[][]=
            {
                    {"Buenos Aires","Santiago","Asuncion","Quito"},
                    {"La Paz","Asunction","Bogota","Quito"},
                    {"Brasilia","Paramaribo","Georgetown","La Paz"},
                    {"Santiago","Montevideo","Buenos Aires","Georgetown"},
                    {"Quito","Lima","Caracas","Buenos Aires"},
                    {"Georgetown","La Paz","Caracas","Brasilia"},
                    {"Bogota","Georgetown","La Paz","Asuncion"},
                    {"Asuncion","Caracas","Lima","Bogota"},
                    {"Lima","Buenos Aires","Montevideo","Caracas"},
                    {"Paramaribo","Brasilia","Quito","Lima"},
                    {"Lima","Bogota","Quito","Montevideo"},
                    {"Caracas","Asuncion","Santiago","Paramaribo"}
            };

    public String myCorrectAnswersApld[]=
            {
                    "Buenos Aires",
                    "La Paz",
                    "Brasilia",
                    "Santiago",
                    "Quito",
                    "Georgetown",
                    "Bogota",
                    "Asuncion",
                    "Lima",
                    "Paramaribo",
                    "Montevideo",
                    "Caracas",

            };

    public String getQuestionApld(int a) {
        String question = myQuestionsApld[a];
        return question;
    };

    public String getChoice1Apld(int a) {
        String choice = myChoicesApld[a][0];
        return choice;
    };

    public String getChoice2Apld(int a) {
        String choice = myChoicesApld[a][1];
        return choice;
    };

    public String getChoice3Apld(int a) {
        String choice = myChoicesApld[a][2];
        return choice;
    };

    public String getChoice4Apld(int a) {
        String choice = myChoicesApld[a][3];
        return choice;
    };

    public String getCorrectAnswerApld(int a) {
        String answer = myCorrectAnswersApld[a];
        return answer;
    };
}
