package com.example.tregula.stolicepastw;

public class QuestionsAfr {
    public String myQuestionsAfr[] =
            {
                    "Algieria",
                    "Angola",
                    "Benin(Dahomej)",
                    "Botswana",
                    "Burkinia Faso",
                    "Burundi",
                    "Czad",
                    "Dżibuti",
                    "Egipt",
                    "Etiopia",
                    "Erytera",
                    "Gabou",
                    "Ghana",
                    "Gwinea",
                    "Gwinea Bissan",
                    "Gwinea Równikowa",
                    "Kamerun",
                    "Kenia",
                    "Kongo",
                    "Kongo",
                    "Lesotho",
                    "Liberia",
                    "Libia",
                    "Madagaskar",
                    "Malawi",
                    "Mali",
                    "Maroko",
                    "Mauretania",
                    "Mozambik",
                    "Namibia",
                    "Niger",
                    "Nigeria",
                    "RPA",
                    "Rep. Środkowoafrykańska",
                    "Ruanda",
                    "Sahara Zach.",
                    "Senegal",
                    "Sierra Leone",
                    "Somalia",
                    "Sudan",
                    "Suazi",
                    "Tanzania",
                    "Togo",
                    "Tunezja",
                    "Uganda",
                    "Wybrz. Kości Słoniowej",
                    "Dem. Republika Konga",
                    "Zambia",
                    "Zimbabwe"
            };

    public String myChoicesAfr[][] =
            {
                    {"Wagadugu", "Abudża", "Windhoek", "Algier "},
                    {"Trypolis", "Addis Abeba", "Wagadugu", "Luanda"},
                    {"Porto Novo", "Akra", "Tunis", "Algier"},
                    {"Ndżamena", "Al.-Ujun", "Trypolis", "Gaborone"},
                    {"Nairobi", "Algier ", "Rabat", "Wagadugu"},
                    {"Monrowia", "Antananarywa", "Pretoria", "Bużumbura"},
                    {"Maseru ", "Asmara", "Porto Novo", "Ndżamena"},
                    {"Malabo", "Bamako", "Niamej", "Dżibuti"},
                    {"Luanda", "Bangi", "Ndżamena", "Kair"},
                    {"Libreville", "Bissan", "Nawakszut", "Addis Abeba"},
                    {"Konakriy", "Brazzaville", "Nairobi", "Asmara"},
                    {"Kinszasa", "Bużumbura", "Monrowia", "Libreville"},
                    {"Kair", "Chartum", "Mogadiszu", "Akra"},
                    {"Jaunde", "Dakar", "Mbabane", "Konakriy"},
                    {"Gaborone", "Dodoma", "Maseru ", "Bissan"},
                    {"Dżibuti", "Dakar", "Maputo", "Malabo"},
                    {"Bużumbura", "Freetown", "Malabo", "Jaunde"},
                    {"Brazzaville", "Gaborone", "Lusaka", "Nairobi"},
                    {"Bissan", "Harare", "Luanda", "Kinszasa"},
                    {"Asmara", "Jamusukro", "Lome", "Brazzaville"},
                    {"Antananarywa", "Jaunde", "Lilongwe", "Maseru "},
                    {"Algier ", "Kair", "Libreville", "Monrowia"},
                    {"Akra", "Kampala", "Konakriy", "Trypolis"},
                    {"Addis Abeba", "Kigali", "Kinszasa", "Antananarywa"},
                    {"Abudża", "Kinszasa", "Kinszasa", "Lilongwe"},
                    {"Al.-Ujun", "Kinszasa", "Kigali", "Bamako"},
                    {"Bamako", "Konakriy", "Kampala", "Rabat"},
                    {"Bangi", "Libreville", "Kair", "Nawakszut"},
                    {"Chartum", "Lilongwe", "Jaunde", "Maputo"},
                    {"Dakar", "Lome", "Jamusukro", "Windhoek"},
                    {"Dodoma", "Luanda", "Harare", "Niamej"},
                    {"Freetown", "Lusaka", "Gaborone", "Abudża"},
                    {"Harare", "Malabo", "Freetown", "Pretoria"},
                    {"Jamusukro", "Maputo", "Dżibuti", "Bangi"},
                    {"Kampala", "Maseru ", "Dodoma", "Kigali"},
                    {"Kigali", "Mbabane", "Dakar", "Al.-Ujun"},
                    {"Kinszasa", "Mogadiszu", "Chartum", "Dakar"},
                    {"Lilongwe", "Monrowia", "Bużumbura", "Freetown"},
                    {"Lome", "Nairobi", "Brazzaville", "Mogadiszu"},
                    {"Lusaka", "Nawakszut", "Bissan", "Chartum"},
                    {"Maputo", "Ndżamena", "Bangi", "Mbabane"},
                    {"Mbabane", "Niamej", "Bamako", "Dodoma"},
                    {"Mogadiszu", "Porto Novo", "Asmara", "Lome"},
                    {"Nawakszut", "Pretoria", "Antananarywa", "Tunis"},
                    {"Niamej", "Rabat", "Algier ", "Kampala"},
                    {"Pretoria", "Trypolis", "Al.-Ujun", "Jamusukro"},
                    {"Rabat", "Tunis", "Akra", "Kinszasa"},
                    {"Tunis", "Wagadugu", "Addis Abeba", "Lusaka"},
                    {"Windhoek", "Windhoek", "Abudża", "Harare"},


            };

    public String myCorrectAnswersAfr[] =
            {
                    "Algier ",
                    "Luanda",
                    "Porto Novo",
                    "Gaborone",
                    "Wagadugu",
                    "Bużumbura",
                    "Ndżamena",
                    "Dżibuti",
                    "Kair",
                    "Addis Abeba",
                    "Asmara",
                    "Libreville",
                    "Akra",
                    "Konakriy",
                    "Bissan",
                    "Malabo",
                    "Jaunde",
                    "Nairobi",
                    "Kinszasa",
                    "Brazzaville",
                    "Maseru ",
                    "Monrowia",
                    "Trypolis",
                    "Antananarywa",
                    "Lilongwe",
                    "Bamako",
                    "Rabat",
                    "Nawakszut",
                    "Maputo",
                    "Windhoek",
                    "Niamej",
                    "Abudża",
                    "Pretoria",
                    "Bangi",
                    "Kigali",
                    "Al.-Ujun",
                    "Dakar",
                    "Freetown",
                    "Mogadiszu",
                    "Chartum",
                    "Mbabane",
                    "Dodoma",
                    "Lome",
                    "Tunis",
                    "Kampala",
                    "Jamusukro",
                    "Kinszasa",
                    "Lusaka",
                    "Harare"
            };

    public String getQuestionAfr(int a) {
        String question = myQuestionsAfr[a];
        return question;
    };

    public String getChoice1Afr(int a) {
        String choice = myChoicesAfr[a][0];
        return choice;
    };

    public String getChoice2Afr(int a) {
        String choice = myChoicesAfr[a][1];
        return choice;
    };

    public String getChoice3Afr(int a) {
        String choice = myChoicesAfr[a][2];
        return choice;
    };

    public String getChoice4Afr(int a) {
        String choice = myChoicesAfr[a][3];
        return choice;
    };

    public String getCorrectAnswerAfr(int a) {
        String answer = myCorrectAnswersAfr[a];
        return answer;
    };

}
