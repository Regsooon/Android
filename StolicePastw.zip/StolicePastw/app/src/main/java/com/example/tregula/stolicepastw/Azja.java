package com.example.tregula.stolicepastw;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Azja extends AppCompatActivity {

    Button answer1,answer2,answer3,answer4;
    TextView score,question;

    private QuestionsAzj myQuestions = new QuestionsAzj();

    private  String myAnswer;
    private int myScore=0;
    private  int myQuestionsLenght = myQuestions.myQuestionsAzj.length;
    private int progress=0;
    private  int endPoint=5;

    Random r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_azja);

        r=new Random();
        answer1= (Button) findViewById(R.id.answer1);
        answer2= (Button) findViewById(R.id.answer2);
        answer3= (Button) findViewById(R.id.answer3);
        answer4= (Button) findViewById(R.id.answer4);
        final Handler handler = new Handler();
        score = (TextView) findViewById(R.id.score);
        question = (TextView) findViewById(R.id.capital);
        score.setText("Punkty: 0");


        updateQuestionAzj(r.nextInt(myQuestionsLenght));

        progress=0;

        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer1.getText() == myAnswer) {
                    myScore++;

                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);

                    answer1.setBackgroundColor(getResources().getColor(R.color.goodAnswer));
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));
                        }
                    }, 1000);

                } else {


                    answer1.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));

                        }
                    }, 1000);
                }


            }
        });

        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer2.getText() == myAnswer) {
                    myScore++;

                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);

                    answer2.setBackgroundColor(getResources().getColor(R.color.goodAnswer));

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));
                        }
                    }, 1000);

                } else {


                    answer2.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));

                        }
                    }, 1000);
                }


            }
        });

        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer3.getText() == myAnswer) {
                    myScore++;

                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);

                    answer3.setBackgroundColor(getResources().getColor(R.color.goodAnswer));

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));
                        }
                    }, 1000);

                } else {


                    answer3.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));

                        }
                    }, 1000);
                }

            }
        });

        answer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer4.getText() == myAnswer) {
                    myScore++;

                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);

                    answer4.setBackgroundColor(getResources().getColor(R.color.goodAnswer));
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));
                        }
                    }, 1000);

                } else {


                    answer4.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
                    score.setText("Punkty: " + myScore+"\nPostęp: "+(progress+1)+"/"+endPoint);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateQuestionAzj(r.nextInt(myQuestionsLenght));

                        }
                    }, 1000);
                }

            }
        });

    }

    private void gameOver()
    {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Azja.this);
        alertDialogBuilder
                .setMessage("Koniec Gry! Twój Wynik to: " + myScore)
                .setCancelable(false)
                .setPositiveButton("Nowa Gra!",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {

                                finish();
                            }
                        })
                .setNegativeButton("Wyjście!",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                finish();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void updateQuestionAzj(int number)
    {
        Drawable shape = getResources().getDrawable(R.drawable.round_btn2);
        progress++;

        if (progress>=endPoint) {

            gameOver();

        } else {
            answer1.setBackgroundDrawable(shape);
            answer2.setBackgroundDrawable(shape);
            answer3.setBackgroundDrawable(shape);
            answer4.setBackgroundDrawable(shape);

            question.setText(myQuestions.getQuestionAzj(number));

            question.setText("Wybierz stolicę: \n"+myQuestions.getQuestionAzj(number));
            answer1.setText(myQuestions.getChoice1Azj(number));
            answer2.setText(myQuestions.getChoice2Azj(number));
            answer3.setText(myQuestions.getChoice3Azj(number));
            answer4.setText(myQuestions.getChoice4Azj(number));

            myAnswer = myQuestions.getCorrectAnswerAzj(number);
        }

    }

    }

