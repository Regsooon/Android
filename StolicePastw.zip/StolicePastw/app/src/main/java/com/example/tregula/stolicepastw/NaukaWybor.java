package com.example.tregula.stolicepastw;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NaukaWybor extends AppCompatActivity {

    Button choice1,choice2,choice3,choice4,choice5,choice6,choice7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wybor);

        choice1 = (Button) findViewById(R.id.euro);
        choice2 = (Button) findViewById(R.id.afrk);
        choice3 = (Button) findViewById(R.id.azj);
        choice4 = (Button) findViewById(R.id.apln);
        choice5 = (Button) findViewById(R.id.apld);
        choice6 = (Button) findViewById(R.id.aus);
        choice7 = (Button) findViewById(R.id.exit);

        choice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaEuropa.class));
            }
        });
        choice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaAfryka.class));
            }
        });
        choice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaAzja.class));
            }
        });
        choice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaApln.class));
            }
        });
        choice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaApld.class));
            }
        });
        choice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NaukaAustralia.class));
            }
        });
        choice7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

