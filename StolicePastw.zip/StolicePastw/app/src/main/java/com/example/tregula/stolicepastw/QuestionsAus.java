package com.example.tregula.stolicepastw;

public class QuestionsAus {

    public String myQuestionsAus[]= {
            "Australia",
            "Fidżi",
            "Kiribati",
            "Mikronezja",
            "Nauru",
            "Nowa Zelandia",
            "Palau",
            "Papua-Nowa Gwinea",
            "Samoa",
            "Tonga",
            "Tuvalu",
            "Vanuatu",
            "Wyspy Marshalla",
            "Wyspy Salomona",
    };

    public String myChoicesAus[][] =
            {
                    {"Apia","Bairiki","Canberra","Yaren"},
                    {"Bairiki","Canberra","Suva","Wellington"},
                    {"Canberra","Ngerulmud","Bairiki","Vaiaku"},
                    {"Honiara","Palikir","Palikir","Suva"},
                    {"Majuro","Suva","Yaren","Port Vila"},
                    {"Ngerulmud","Wellington","Wellington","Port Moresby"},
                    {"Nuku'alofa","Yaren","Ngerulmud","Palikir"},
                    {"Palikir","Apia","Port Moresby","Nuku'alofa"},
                    {"Port Moresby","Honiara","Apia","Ngerulmud"},
                    {"Port Vila","Majuro","Nuku'alofa","Majuro"},
                    {"Suva","Nuku'alofa","Vaiaku","Honiara"},
                    {"Vaiaku","Port Moresby","Port Vila","Canberra"},
                    {"Wellington","Port Vila","Majuro","Bairiki"},
                    {"Yaren","Vaiaku","Honiara","Apia"},
            };

    public String myCorrectAnswersAus[] =
            {
                    "Canberra",
                    "Suva",
                    "Bairiki",
                    "Palikir",
                    "Yaren",
                    "Wellington",
                    "Ngerulmud",
                    "Port Moresby",
                    "Apia",
                    "Nuku'alofa",
                    "Vaiaku",
                    "Port Vila",
                    "Majuro",
                    "Honiara",
            };


    public String getQuestionAus(int a) {
        String question = myQuestionsAus[a];
        return question;
    };

    public String getChoice1Aus(int a) {
        String choice = myChoicesAus[a][0];
        return choice;
    };

    public String getChoice2Aus(int a) {
        String choice = myChoicesAus[a][1];
        return choice;
    };

    public String getChoice3Aus(int a) {
        String choice = myChoicesAus[a][2];
        return choice;
    };

    public String getChoice4Aus(int a) {
        String choice = myChoicesAus[a][3];
        return choice;
    };

    public String getCorrectAnswerAus(int a) {
        String answer = myCorrectAnswersAus[a];
        return answer;
    };
}
