package com.example.tregula.stolicepastw;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NaukaAzja extends AppCompatActivity {
    Button next,previous,exit;
    TextView progr,capital;

    private QuestionsAzj myQuestions = new QuestionsAzj();

    private int progress=0;
    private int endPoint=myQuestions.myQuestionsAzj.length;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nauka_azja);

        next= (Button) findViewById(R.id.next);
        previous= (Button) findViewById(R.id.previous);
        exit = (Button) findViewById(R.id.exit);
        progr=(TextView) findViewById(R.id.progr);
        capital=(TextView) findViewById(R.id.capital);
        progr.setText("Postęp: "+(progress+1)+"/"+endPoint);

        updateQuestion(progress);
        buttons();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progress++;
                progr.setText("Postęp: "+progress+"/"+(endPoint-1));
                updateQuestion(progress);
                buttons();

            }

        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progress--;
                progr.setText("Postęp: "+progress+"/"+(endPoint-1));
                updateQuestion(progress);
                buttons();

            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
    private void buttons()
    {
        Drawable shape = getResources().getDrawable(R.drawable.round_btn3);
        if (progress==(endPoint-1))
        {
            next.setEnabled(false);
            next.setBackgroundDrawable(shape);

        }
        else
        {
            next.setEnabled(true);

        }

        if (progress==0)
        {
            previous.setEnabled(false);
            previous.setBackgroundDrawable(shape);
        }
        else
        {
            previous.setEnabled(true);
        }
    }


    private void updateQuestion(int number)
    {
        Drawable shape = getResources().getDrawable(R.drawable.round_btn2);
        buttons();


        next.setBackgroundDrawable(shape);
        previous.setBackgroundDrawable(shape);
        capital.setText(myQuestions.getQuestionAzj(number)+"\n\n"+myQuestions.getCorrectAnswerAzj(number));



    }
}
